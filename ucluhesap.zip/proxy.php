<?php
// proxy.php - InfinityFree dış dünya bağlantı çözümü
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Content-Type: text/plain; charset=utf-8');

// OPTIONS isteğine cevap ver
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$url = isset($_GET['url']) ? $_GET['url'] : '';

if(empty($url)) {
    die('{"error":"URL gerekli"}');
}

// SADECE bizim API'lerimize izin ver
$izinli_domain = 'apiservices.alwaysdata.net';
$izinli_path = '/apiservices/';

if(strpos($url, $izinli_domain) === false || strpos($url, $izinli_path) === false) {
    die('{"error":"Bu API kullanılamaz"}');
}

// User-Agent listesi (güncel)
$user_agents = [
    'Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 Safari/605.1.15',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148',
    'Mozilla/5.0 (iPad; CPU OS 17_3 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148'
];

// Proxy list (çalışan proxy'ler)
$proxies = [
    'tcp://45.87.245.5:3128',
    'tcp://185.217.137.19:8080',
    'tcp://94.23.222.122:41258',
    'tcp://51.158.108.26:8811',
    'tcp://167.99.123.45:1080'
];

// Rastgele seç
$random_ua = $user_agents[array_rand($user_agents)];
$random_proxy = $proxies[array_rand($proxies)];

// Log tutma (isteğe bağlı)
$log_entry = date('Y-m-d H:i:s') . " - " . $_SERVER['REMOTE_ADDR'] . " - " . $url . "\n";
file_put_contents('proxy_log.txt', $log_entry, FILE_APPEND);

// cURL ile istek yap
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_USERAGENT, $random_ua);
curl_setopt($ch, CURLOPT_PROXY, $random_proxy);
curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-Forwarded-For: ' . explode(':', $random_proxy)[0],
    'Accept: application/json, text/plain, */*',
    'Accept-Language: tr-TR,tr;q=0.9,en;q=0.8'
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

// Proxy hatası olursa proxysiz dene
if($error || $http_code !== 200) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, $random_ua);
    $response = curl_exec($ch);
    curl_close($ch);
}

echo $response;
?>